﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace A2NikhilAhujaP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter age?");
            string x = Console.ReadLine();
            int age = int.Parse(x);
            double tution;
            if (age <= 18)
            {
                tution = 300 + (300* 13 / 100);
                Console.WriteLine("you must pay tuition fees:$" +tution);
            }
            else if (age > 18 && age < 50)
            {
                tution = 500 + (500 * 13 / 100);
                Console.WriteLine("you must pay tuition fees:$" + tution);
            }
            else
            {
                tution = 400 + (400 * 13 / 100);
                Console.WriteLine("you must pay tuition fees:$" + tution);

            }
            Console.WriteLine("Canadian Citizen or not(yes/no)?");
            string student = (Console.ReadLine());
            if (student == "yes")
            {
                Console.WriteLine("no extra charges");
            }
            else if (student == "no")
            {
                tution=tution+ 100;
                Console.WriteLine("$100 extra charged on fees:$" +tution);
            }
            else
            {
                Console.WriteLine("enter valid selection");
            }
            Console.WriteLine("enter Registeration month:");
            Console.WriteLine("a)SUMMER(may,june,july,august)");
            Console.WriteLine("b)FALL(september,october,november,december)");
            Console.WriteLine("c).WINTER(january,february,march,april)");
            string input = Console.ReadLine();
            double reg;
            switch (input)
            {
                case "c":
                    reg= 250 + 250 * 13 / 100;
                    Console.WriteLine("REGISTRATION FEES FOR SEMESTER:$" + reg);
                    double FinalTotal = tution + reg;
                    Console.WriteLine("FINAL TOTAL FEES:$" + FinalTotal);
                    break;
                case "b":
                    reg = 220 + 220 * 13 / 100;
                    Console.WriteLine("REGISTRATION FEES FOR SEMESTER: $" + reg);
                    FinalTotal = tution + reg;
                    Console.WriteLine("FINAL TOTAL FEES:$" + FinalTotal);
                    break;
                case "a":
                    regfees = 150 + 150 * 13 / 100;
                    Console.WriteLine("REGISTRATION FEES FOR SEMESTER:$" + reg);
                    FinalTotal =tution+ reg;
                    Console.WriteLine("FINAL TOTAL FEES:$" + FinalTotal);
                    break;
                default:
                    Console.WriteLine("do a invalid selection");
                    break;
            }
          
        }
    }

}